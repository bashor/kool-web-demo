package org.jetbrains.jps.artifacts

/**
 * @author nik
 */
interface ArtifactProperties {
}
