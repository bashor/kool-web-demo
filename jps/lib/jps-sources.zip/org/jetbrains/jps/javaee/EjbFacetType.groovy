package org.jetbrains.jps.javaee

/**
 * @author nik
 */
class EjbFacetType extends JavaeeFacetTypeBase {
  EjbFacetType() {
    super("ejb")
  }
}
