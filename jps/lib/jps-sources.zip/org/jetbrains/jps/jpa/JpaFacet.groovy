package org.jetbrains.jps.jpa

import org.jetbrains.jps.idea.Facet

/**
 * @author nik
 */
class JpaFacet extends Facet {
  final List<String> descriptors = []
}
