package org.jetbrains.jps.scala

import org.jetbrains.jps.idea.Facet

class ScalaFacet extends Facet {
  String compilerLibraryName
}
